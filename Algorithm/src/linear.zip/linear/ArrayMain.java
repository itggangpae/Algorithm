package linear;

public class ArrayMain {

	public static void main(String[] args) {
		Object[] intAr = { 100, 200, 400 };
		for (Object temp : intAr) {
			System.out.print(temp + "\t");
		}
		System.out.println();

		// 200 다음의 위치에 300을 추가
		intAr = Array.insert(intAr, 2, 300);
		for (Object temp : intAr) {
			System.out.print(temp + "\t");
		}
		System.out.println();

		// 마지막 위치에 500을 추가
		intAr = Array.append(intAr, 500);
		for (Object temp : intAr) {
			System.out.print(temp + "\t");
		}
		System.out.println();
		
		// 200을 제거 
		intAr = Array.delete(intAr, 1);
		for (Object temp : intAr) {
			System.out.print(temp + "\t");
		}
		System.out.println();

	}

}
